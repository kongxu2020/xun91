var online=new Array();
if (!document.layers)
document.write('<div id=divStayTopLeft style=position:absolute>');
document.write('<table cellSpacing="0" cellPadding="0" width="110" border="0" id="qqtab">');
document.write('    <tr>');


var QQOnlineSettings=1;

document.write('      <td width="110" onclick="if(document.all.qqtab.style.display==\'none\'){document.all.qqtab.style.display=\'\'} else {document.all.qqtab.style.display=\'none\'}"><img src="../include/QQOnlineimages/1/top.gif" border="0"></td>');
document.write('    </tr>');
document.write('    <tr id="qqstab">');
document.write('      <td valign="middle" align="center" background="../include/QQOnlineimages/1/middle.gif">');    
document.write('<table border="0" width="80" cellSpacing="0" cellPadding="0">');
document.write('  <tr>');
document.write('    <td width="80" height="5" border="0" colspan="2"></td>');
document.write('  </tr>');


document.write('  <tr>');
if (online[0]==0)
{
document.write('    <td width="25" height="22" valign="middle" align="center">');
document.write("<img src=../include/QQOnlineimages/1_f.gif border=0>");
document.write('    </td>');
document.write('    <td width="55" height="22" valign="middle" align="left">');
document.write("<a target=blank href=http://wpa.qq.com/msgrd?V=1&amp;Uin=32731676&amp;Site=��ͨ&amp;Menu=yes>32731676</a><br>");
document.write('    </td>');
}
else
{
document.write('    <td width="25" height="22" valign="middle" align="center">');
document.write("<img src=../include/QQOnlineimages/1_m.gif border=0>");
document.write('    </td>');
document.write('    <td width="55" height="22" valign="middle" align="left">');
document.write("<a target=blank href=http://wpa.qq.com/msgrd?V=1&amp;Uin=32731676&amp;Site=��ͨ&amp;Menu=yes>32731676</a><br>");
document.write('    </td>');
}
document.write('  </tr>');





document.write('</table>');     
document.write('</td>');
document.write('    </tr>');
document.write('    <tr>');
document.write('      <td width="110" onclick="if(document.all.qqstab.style.display==\'none\'){document.all.qqstab.style.display=\'\'} else {document.all.qqstab.style.display=\'none\'}"><img src="../include/QQOnlineimages/1/bottom.gif" border="0"></td>');
document.write('    </tr>');
document.write('</table>');




var verticalpos="frombottom"
if (!document.layers)
document.write('</div>')
function JSFX_FloatTopDiv()
{
	var startX =2
	startY =500
	var ns = (navigator.appName.indexOf("Netscape") != -1);
	var d = document;
	function ml(id)
	{
		var el=d.getElementById?d.getElementById(id):d.all?d.all[id]:d.layers[id];
		if(d.layers)el.style=el;
		el.sP=function(x,y){this.style.left=x;this.style.top=y;};
		el.x = startX;
		if (verticalpos=="fromtop")
		el.y = startY;
		else{
		el.y = ns ? pageYOffset + innerHeight : document.body.scrollTop + document.body.clientHeight;
		el.y -= startY;
		}
		return el;
	}
	window.stayTopLeft=function()
	{
		if (verticalpos=="fromtop"){
		var pY = ns ? pageYOffset : document.body.scrollTop;
		ftlObj.y += (pY + startY - ftlObj.y)/8;
		}
		else{
		var pY = ns ? pageYOffset + innerHeight : document.body.scrollTop + document.body.clientHeight;
		ftlObj.y += (pY - startY - ftlObj.y)/8;
		}
		ftlObj.sP(ftlObj.x, ftlObj.y);
		setTimeout("stayTopLeft()", 10);
	}
	ftlObj = ml("divStayTopLeft");
	stayTopLeft();
}
JSFX_FloatTopDiv();
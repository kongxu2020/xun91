function JobCheck()
{
	if (document.form.name.value == "")
		{
			alert("��������������");
			document.form.name.focus();
			return false;
		}
	if (document.form.cardid.value == "")
		{
			alert("����������֤����");
			document.form.cardid.focus();
			return false;
		}
	if (document.form.tel.value == "")
		{
			alert("������绰����");
			document.form.tel.focus();
			return false;
		}
	var mail = document.form.email.value;
	if (mail.indexOf('@',0) == -1 || mail.indexOf('.',0) == -1)
		{
			alert("�������Email�д���\n�����¼�����Email");
			document.form.email.focus();
			return false;
		}
	if (document.form.email.value == "")
		{
		alert("����������EMAIL��ַ");
		document.form.email.focus();
		return false;
		}
return true;
}

// ѡ��ɫ
function SelectColor(what){
	var dEL = document.all(what);
	var sEL = document.all("S"+what);
	var url = "../manage/dialog/Selcolor.htm?color="+encodeURIComponent(dEL.value);
	var arr = showModalDialog(url,window,"dialogWidth:280px;dialogHeight:250px;help:no;scroll:no;status:no");
	if (arr) {
		dEL.value=arr;
		sEL.style.backgroundColor=arr;
	}
}

//�ı��������е���
function ChangeMType(T_Id){
    document.form.M_Id.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form.M_Id.options[document.form.M_Id.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   

//�ı���������е���
function ChangeSType(M_Id){
    document.form.S_Id.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form.S_Id.options[document.form.S_Id.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}   


//�ı�City��
function ChangeCity(T_Id){
    document.form0.CityId.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Citycount; i++){
	   if (CitySubcat[i][1] == M_Id){ 
		 document.form0.CityId.options[document.form0.CityId.length] = new Option(CitySubcat[i][0], CitySubcat[i][2]);
		}
	}
}   

//�ı�Town����е���
function ChangeTown(M_Id){
    document.form0.TownId.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Towncount; i++){
	   if (TownSubcat[i][1] == S_Id){ 
		 document.form0.TownId.options[document.form0.TownId.length] = new Option(TownSubcat[i][0], TownSubcat[i][2]);
		}
	}
}   







function doChange(objText, objDrop){
	if (!objDrop) return;
	var str = objText.value;
	var arr = str.split("|");
	var nIndex = objDrop.selectedIndex;
	objDrop.length=1;
	for (var i=0; i<arr.length; i++){
		objDrop.options[objDrop.length] = new Option(arr[i], arr[i]);
	}
	objDrop.selectedIndex = nIndex;
}

function IsDigit(){
  return ((event.keyCode >= 48) && (event.keyCode <= 57));
}


function CheckAll(form){
	for (var i=0;i<form.elements.length;i++){var e = form.elements[i];if (e.name != 'chkall')e.checked = form.chkall.checked;
	}
}

function CheckClick(msg){
	if(confirm(msg)){event.returnValue=true;}else{event.returnValue=false;
	}
}

function NewWindow(mypage, myname, w, h, scroll) {
	var winl = (screen.width - w) / 2;
	var wint = (screen.height - h) / 2;
	winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable'
	win = window.open(mypage, myname, winprops)
	if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}


//��Աע��

function CheckMemberReg(form){
	if (form.MemberName.value == ""){
		alert("����д��Ա����!")
		form.MemberName.focus();
		return false;
	}
	if (form.MemberPass.value == ""){
		alert("����д���룡")
		form.MemberPass.focus();
		return false;
	}
	if (form.MemberPass2.value == ""){
		alert("����д�ظ����룡")
		form.MemberPass2.focus();
		return false;
	}
	
	if (form.MemberPass2.value !==form.MemberPass.value){
		alert("�������ظ����������ͬ��")
		form.MemberPass2.focus();
		return false;
	}
	
	if (form.MemberRealName.value ==""){
		alert("����д��ʵ������")
		form.MemberRealName.focus();
		return false;
	}	
	
	if (form.MemberTel.value ==""){
		alert("����д�̶��绰��")
		form.MemberTel.focus();
		return false;
	}	
	
	if (form.MemberFax.value ==""){
		alert("����д���棡")
		form.MemberFax.focus();
		return false;
	}	
	
	if (form.MemberMobile.value ==""){
		alert("����д�ֻ���")
		form.MemberMobile.focus();
		return false;
	}		
	
	if (form.MemberEmail.value.length < 5){
		alert("����д��������!Please fill in Email!")
		form.MemberEmail.focus();
		return false;
	}
  if(form.MemberEmail.value.indexOf("@") == -1|| form.MemberEmail.value.indexOf('.',0) == -1)
  {
    alert("����д��ȷ�ĵ�������!The Email must be exactitude!")
    form.MemberEmail.focus()
    return false
  }  	
  
  if (form.MemberComName.value ==""){
		alert("����д��˾���ƣ�")
		form.MemberComName.focus();
		return false;
	}		
  
  if (form.MemberComYewu.value ==""||form.MemberComYewu.value.length < 8){
		alert("����д��˾��Ӫҵ��")
		form.MemberComYewu.focus();
		return false;
	}	
	
	  if (form.MemberComYewu.value.length >255){
		alert("��˾��Ӫҵ���ܹ�����255���ַ���")
		form.MemberComYewu.focus();
		return false;
	}	

	
	
	
  if (form.VCode.value ==""){
		alert("����д��֤�룡")
		form.VCode.focus();
		return false;
	}		
  	
	
		
	return true;
}

//���߶���
function CheckFeedback(form){
	if (form.F_productName.value == ""){
		alert("�������Ʒ����!Please fill in ProductName!")
		form.F_productName.focus();
		return false;
	}

	if (form.F_specification.value == ""){
		alert("�������Ʒ���!Please fill in Products Size!")
		form.F_specification.focus();
		return false;
	}
	if (form.F_tel1.value == ""){
		alert("����д�绰����!Please fill in Tel!")
		form.F_tel1.focus();
		return false;
	}
	if (form.F_tel.value == ""){
		alert("����д�绰!Please fill in Tel!")
		form.F_tel.focus();
		return false;
	}
	if (form.F_fax1.value.length < 1){
		alert("����д��������!Please fill in Fax!")
		form.F_fax1.focus();
		return false;
	}
	if (form.F_fax.value.length < 5){
		alert("����д����!Please fill in Fax!")
		form.F_fax.focus();
		return false;
	}
	if (form.F_address.value.length < 1){
		alert("����д��˾��ַ!Please fill in Add!")
		form.F_address.focus();
		return false;
	}
  if(form.F_Mail.value.indexOf("@") == -1|| form.F_Mail.value.indexOf('.',0) == -1)
  {
    alert("����д��ȷ�ĵ�������!The Email must be exactitude!")
    form.F_Mail.focus()
    return false
  }  	
		
	return true;
}
//����
function CheckFeedback1(form){
	if (form.F_Name.value == ""){
		alert("����������!Please fill in Name!")
		form.F_Name.focus();
		return false;
	}

	if (form.F_tel11.value == ""){
		alert("����д�绰����!Please fill in Tel!")
		form.F_tel11.focus();
		return false;
	}
	
	if (form.F_tel.value == ""){
		alert("����д�绰!Please fill in Tel!")
		form.F_tel.focus();
		return false;
	}
	
	if (form.F_fax11.value.length < 1){
		alert("����д��������!Please fill in Fax!")
		form.F_fax11.focus();
		return false;
	}
	
	if (form.F_fax.value.length < 5){
		alert("����д����!Please fill in Fax!")
		form.F_fax.focus();
		return false;
	}

	if (form.F_Content.value.length < 1){
		alert("����д��������!Please fill in Centet!")
		form.F_Content.focus();
		return false;
	}

	return true;
}
//��������

function CheckGuestbook(form){
	if (form.G_Name1.value ==""){
		alert("����������!Please fill in ProductName!")
		form.G_Name1.focus();
		return false;
	}
	if (form.G_tel1.value.length < 7){
		alert("����д�绰!Please fill in Tel!")
		form.G_tel1.focus();
		return false;
	}
	if (form.G_Fax1.value.length < 7){
		alert("����д����!Please fill in Fax!")
		form.G_Fax1.focus();
		return false;
	}
	if (form.G_Content1.value.length < 1){
		alert("����д��������!Please fill in Centet!")
		form.G_Content1.focus();
		return false;
	}
  if(form.G_Email.value.indexOf("@") == -1|| form.G_Email.value.indexOf('.',0) == -1)
  {
    alert("����д��ȷ�ĵ�������!The Email must be exactitude!")
    form.G_Email.focus()
    return false
  }  	
		
	return true;
}


//-----------------------------------------------------------
//�ı��������е���
//0
function ChangeMType0(T_Id){
    document.form1.M_Id0.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id0.options[document.form1.M_Id0.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType0(M_Id){
    document.form1.S_Id0.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id0.options[document.form1.S_Id0.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}


//1
function ChangeMType1(T_Id){
    document.form1.M_Id1.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id1.options[document.form1.M_Id1.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType1(M_Id){
    document.form1.S_Id1.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id1.options[document.form1.S_Id1.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}

//2
function ChangeMType2(T_Id){
    document.form1.M_Id2.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id2.options[document.form1.M_Id2.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType2(M_Id){
    document.form1.S_Id2.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id2.options[document.form1.S_Id2.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}

//3
function ChangeMType3(T_Id){
    document.form1.M_Id3.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id3.options[document.form1.M_Id3.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType3(M_Id){
    document.form1.S_Id3.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id3.options[document.form1.S_Id3.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}

//4
function ChangeMType4(T_Id){
    document.form1.M_Id4.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id4.options[document.form1.M_Id4.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType4(M_Id){
    document.form1.S_Id4.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id4.options[document.form1.S_Id4.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}

//5
function ChangeMType5(T_Id){
    document.form1.M_Id5.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id5.options[document.form1.M_Id5.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType5(M_Id){
    document.form1.S_Id5.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id5.options[document.form1.S_Id5.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}


//6
function ChangeMType6(T_Id){
    document.form1.M_Id6.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id6.options[document.form1.M_Id6.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType6(M_Id){
    document.form1.S_Id6.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id6.options[document.form1.S_Id6.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}

//7
function ChangeMType7(T_Id){
    document.form1.M_Id7.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id7.options[document.form1.M_Id7.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType7(M_Id){
    document.form1.S_Id7.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id7.options[document.form1.S_Id7.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}


//8
function ChangeMType8(T_Id){
    document.form1.M_Id8.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id8.options[document.form1.M_Id8.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType8(M_Id){
    document.form1.S_Id8.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id8.options[document.form1.S_Id8.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}

//9
function ChangeMType9(T_Id){
    document.form1.M_Id9.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id9.options[document.form1.M_Id9.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType9(M_Id){
    document.form1.S_Id9.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id9.options[document.form1.S_Id9.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}


//10
function ChangeMType10(T_Id){
    document.form1.M_Id10.length = 1; 
    var M_Id=T_Id;
    var i;
    for (i=0;i < Onecount; i++){
	   if (Subcat[i][1] == M_Id){ 
		 document.form1.M_Id10.options[document.form1.M_Id10.length] = new Option(Subcat[i][0], Subcat[i][2]);
		}
	}
}   
//�ı���������е���
function ChangeSType10(M_Id){
    document.form1.S_Id10.length = 1; 
    var S_Id=M_Id;
    var i;
    for (i=0;i < Twocount; i++){
	   if (SubScat[i][1] == S_Id){ 
		 document.form1.S_Id10.options[document.form1.S_Id10.length] = new Option(SubScat[i][0], SubScat[i][2]);
		}
	}
}
//-----------------------------------------------------------
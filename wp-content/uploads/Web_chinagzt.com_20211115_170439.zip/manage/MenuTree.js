﻿var KaitongMenu_openedfolderimage_src="Images/Menu_Openedfolder.gif";
var KaitongMenu_closedfolderimage_src="Images/Menu_Closedfolder.gif";
var KaitongMenu_menufileimage_src="Images/Menu_File.gif";
var KaitongMenu_treetext=new Array();
var KaitongMenu_treeurl=new Array();
var KaitongMenu_treeurltarget=new Array();
var KaitongMenu_treeNum=0;
document.write("<style type='text/css'>.blockhide{display:none;} .blockmove{overflow: hidden;height:1px;display:block;} .blockshow{overflow: visible; display:block;} .hideme{overflow: visible;display:none;} .showme{overflow: visible;display:block;} .KaitongMenu td{font-size:12px;} </style>");
function outinit(itemNo,dir,blockheight){ //缩小一个div的高度
  var subfiles=document.getElementById("item"+itemNo);
  if(blockheight==0){
	subfiles.className="blockshow";
	subfiles.style.height='';
	blockheight=parseInt(subfiles.offsetHeight);
	if(dir>0) subfiles.className="blockmove";
  }
  var outinspeed=blockheight/10;
  var nowheight=parseInt(subfiles.offsetHeight)+outinspeed*dir;
  if(nowheight<=0){
    subfiles.className="blockhide";
	return;
  }else{
    subfiles.className="blockmove";
  }
  if(nowheight>=blockheight && dir>0){
    subfiles.className="blockshow";
	subfiles.style.height='';
	return;
  }
  subfiles.style.height=nowheight;
  subfiles.scrollTop=blockheight;
  parentsresize(subfiles);
  setTimeout("outinit("+itemNo+","+dir+","+blockheight+")",15);
}
function parentsresize(obj){ //缩小父类div的高度
	do{
		if(obj.className=="KaitongMenu"){
			break;
		}
		if(obj.className=="blockshow"){
			obj.style.height="";
		}
	}while(obj=obj.parentElement);
}
function showhideit(itemNo){
  var showfolder=document.images["openedfolderimage"+itemNo];
  var hidefolder=document.images["closedfolderimage"+itemNo];
  var subfiles=document.getElementById("item"+itemNo);
  if(subfiles.className=="blockmove") {return;}
  if(showfolder.className=="hideme") {
	hidefolder.className="hideme";
    showfolder.className="showme";
	outinit(itemNo,1,0);
  }
  else {
	showfolder.className="hideme";
    hidefolder.className="showme";
	outinit(itemNo,-1,0);
  }
}
function addtree(text,url,target){
  KaitongMenu_treetext.push(text);
  KaitongMenu_treeurl.push(url?url:"");
  KaitongMenu_treeurltarget.push(target?target:"Main");
}
function getsubnum(text){ //算出前面有几个"-"号
  var newtext=text.replace(/^-*/,"");
  return text.length-newtext.length;
}
function createtree(){
  KaitongMenu_treeNum++;
  var treestatus=new Array();
  var treeendlayer=new Array();
  var openedlayer=new Array();
  var next_subnum=0;
  for(i=KaitongMenu_treetext.length-1;i>=0;i--){ //从后面分析起,是否有为结束位置或有子树枝
    var subnum=getsubnum(KaitongMenu_treetext[i]);
	treestatus[i]=0;
	if(subnum<next_subnum){  //有子目录
	   treeendlayer[next_subnum]=0;
	   treestatus[i]+=1;
	}
	if(!treeendlayer[subnum]){ //结束位置
	   treeendlayer[subnum]=1;
	   treestatus[i]+=2;
	}
	//显然地,既有子目录又是结束位置时 treestatus[i]=3;
	next_subnum=subnum;
  }
  var echo="<div class='KaitongMenu'>";
  for(i=0;i<KaitongMenu_treetext.length;i++){
     if(!KaitongMenu_treetext[i]) continue;
	 var subnum=getsubnum(KaitongMenu_treetext[i]);
	 var newtext=KaitongMenu_treetext[i].replace(/^-*\*?/,"");
	 if(treestatus[i]==1||treestatus[i]==3){
	   var havechild=1;
	 }else{
	   var havechild=0;
	 }
	 if(treestatus[i]==2||treestatus[i]==3){
	   openedlayer[subnum]=0;
	   var barstatus=2;
	 }else{
	   openedlayer[subnum]=1;
	   var barstatus=1;		 
	 }
	 var showme=KaitongMenu_treetext[i].match(/^-*\*/);
	 var openfold=(i==KaitongMenu_treetext.length-1?0:KaitongMenu_treetext[i+1].match(/^-*\*/));
	 var li=i-1;
     if(i>0&&(treestatus[li]==1||treestatus[li]==3)){
	   echo += "<div id='item"+KaitongMenu_treeNum+li+"' class='"+(showme?"blockshow":"blockhide")+"'>";
	 }
	 echo += "<table border='0' cellspacing='0' cellpadding='0' "+(subnum==0?"height=25":"")+"><tr>\n";
	for(j=1;j<subnum;j++){
	  echo += "<td width='20' valign=bottom><img src='Images/"+(openedlayer[j]?"Menu_Bar3.gif":"Menu_Spacer.gif")+"' width='20' height='20'></td>\n";
	}
	if(subnum>0){
	  echo += "<td width='20' valign=bottom><img src='Images/Menu_Bar"+barstatus+".gif' width='20' height='20'></td>";
	}
	var clicktoshowhide=(havechild?" onclick='showhideit("+KaitongMenu_treeNum+""+i+")' style='cursor:pointer;' ":"");
    echo += "<td width='22' valign=bottom "+clicktoshowhide+"><img name='openedfolderimage"+KaitongMenu_treeNum+""+i+"' src='"+(havechild?KaitongMenu_openedfolderimage_src:KaitongMenu_menufileimage_src)+"' class='"+(openfold?"showme":"hideme")+"' width='20' height='20'><img name='closedfolderimage"+KaitongMenu_treeNum+""+i+"' src='"+(havechild?KaitongMenu_closedfolderimage_src:KaitongMenu_menufileimage_src)+"' class='"+(openfold?"hideme":"showme")+"' width='20' height='20'></td>";
	echo += "<td nowrap valign=bottom><a onmousedown='return false;' "+clicktoshowhide+" "+(KaitongMenu_treeurl[i]?"href='"+KaitongMenu_treeurl[i]+"'":"name='#'")+" target='"+KaitongMenu_treeurltarget[i]+"'>"+newtext+"</a></td></tr></table>\n\n";	
     if(barstatus==2&&!havechild){
	   for(j=subnum;j>=0;j--){
	     if(!openedlayer[j]) echo += "</div>";else break;
	   }
	 }
  }
  echo += "</div>";
  document.write(echo);
  //清空列表以接受下一个菜单
  KaitongMenu_treetext=new Array();
  KaitongMenu_treeurl=new Array();
  KaitongMenu_treeurltarget=new Array();
}
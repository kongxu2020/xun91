﻿//定义当前是否大写的状态
window.onload=
	function()
	{
		logpass1=null;		
		initCalc();
	}

var CapsLockValue=0;

var check;
function setVariables() {
tablewidth=630;  // logo width, in pixels
tableheight=20;  // logo height, in pixels
if (navigator.appName == "Netscape") {
horz=".left";
vert=".top";
docStyle="document.";
styleDoc="";
innerW="window.innerWidth";
innerH="window.innerHeight";
offsetX="window.pageXOffset";
offsetY="window.pageYOffset";
}
else {
horz=".pixelLeft";
vert=".pixelTop";
docStyle="";
styleDoc=".style";
innerW="document.body.clientWidth";
innerH="document.body.clientHeight";
offsetX="document.body.scrollLeft";
offsetY="document.body.scrollTop";
   }
}
function checkLocation() {
if (check) {
objectXY="softkeyboard";
var availableX=eval(innerW);
var availableY=eval(innerH);
var currentX=eval(offsetX);
var currentY=eval(offsetY);
x=availableX-tablewidth+currentX;
//y=availableY-tableheight+currentY;
y=currentY;

evalMove();
}
setTimeout("checkLocation()",0);
}
function evalMove() {
//eval(docStyle + objectXY + styleDoc + horz + "=" + x);
eval(docStyle + objectXY + styleDoc + vert + "=" + y);

}


	self.onError=null;
	currentX = currentY = 0;  
	whichIt = null;           
	lastScrollX = 0; lastScrollY = 0;
	NS = (document.layers) ? 1 : 0;
	IE = (document.all) ? 1: 0;
	function heartBeat() {
		if(IE) { diffY = document.body.scrollTop; diffX = document.body.scrollLeft; }
	    if(NS) { diffY = self.pageYOffset; diffX = self.pageXOffset; }
		if(diffY != lastScrollY) {
	                percent = .1 * (diffY - lastScrollY);
	                if(percent > 0) percent = Math.ceil(percent);
	                else percent = Math.floor(percent);
					if(IE) document.all.softkeyboard.style.pixelTop += percent;
					if(NS) document.softkeyboard.top += percent; 
	                lastScrollY = lastScrollY + percent;}
		if(diffX != lastScrollX) {
			percent = .1 * (diffX - lastScrollX);
			if(percent > 0) percent = Math.ceil(percent);
			else percent = Math.floor(percent);
			if(IE) document.all.softkeyboard.style.pixelLeft += percent;
			if(NS) document.softkeyboard.left += percent;
			lastScrollX = lastScrollX + percent;	}		}
	function checkFocus(x,y) { 
	        stalkerx = document.softkeyboard.pageX;
	        stalkery = document.softkeyboard.pageY;
	        stalkerwidth = document.softkeyboard.clip.width;
	        stalkerheight = document.softkeyboard.clip.height;
	        if( (x > stalkerx && x < (stalkerx+stalkerwidth)) && (y > stalkery && y < (stalkery+stalkerheight))) return true;
	        else return false;}
	function grabIt(e) {
	    check = false;
		if(IE) {
			whichIt = event.srcElement;
			while (whichIt.id.indexOf("softkeyboard") == -1) {
				whichIt = whichIt.parentElement;
				if (whichIt == null) { return true; } }
			whichIt.style.pixelLeft = whichIt.offsetLeft;
		    whichIt.style.pixelTop = whichIt.offsetTop;
			currentX = (event.clientX + document.body.scrollLeft);
	   		currentY = (event.clientY + document.body.scrollTop); 	
		} else { 
	        window.captureEvents(Event.MOUSEMOVE);
	        if(checkFocus (e.pageX,e.pageY)) { 
	                whichIt = document.softkeyboard;
	                StalkerTouchedX = e.pageX-document.softkeyboard.pageX;
	                StalkerTouchedY = e.pageY-document.softkeyboard.pageY;} }
	    return true;	}
	function moveIt(e) {
		if (whichIt == null) { return false; }
		if(IE) {
		    newX = (event.clientX + document.body.scrollLeft);
		    newY = (event.clientY + document.body.scrollTop);
		    distanceX = (newX - currentX);    distanceY = (newY - currentY);
		    currentX = newX;    currentY = newY;
		    whichIt.style.pixelLeft += distanceX;
		    whichIt.style.pixelTop += distanceY;
			if(whichIt.style.pixelTop < document.body.scrollTop) whichIt.style.pixelTop = document.body.scrollTop;
			if(whichIt.style.pixelLeft < document.body.scrollLeft) whichIt.style.pixelLeft = document.body.scrollLeft;
			if(whichIt.style.pixelLeft > document.body.offsetWidth - document.body.scrollLeft - whichIt.style.pixelWidth - 20) whichIt.style.pixelLeft = document.body.offsetWidth - whichIt.style.pixelWidth - 20;
			if(whichIt.style.pixelTop > document.body.offsetHeight + document.body.scrollTop - whichIt.style.pixelHeight - 5) whichIt.style.pixelTop = document.body.offsetHeight + document.body.scrollTop - whichIt.style.pixelHeight - 5;
			event.returnValue = false;
		} else { 
			whichIt.moveTo(e.pageX-StalkerTouchedX,e.pageY-StalkerTouchedY);
	        if(whichIt.left < 0+self.pageXOffset) whichIt.left = 0+self.pageXOffset;
	        if(whichIt.top < 0+self.pageYOffset) whichIt.top = 0+self.pageYOffset;
	        if( (whichIt.left + whichIt.clip.width) >= (window.innerWidth+self.pageXOffset-17)) whichIt.left = ((window.innerWidth+self.pageXOffset)-whichIt.clip.width)-17;
	        if( (whichIt.top + whichIt.clip.height) >= (window.innerHeight+self.pageYOffset-17)) whichIt.top = ((window.innerHeight+self.pageYOffset)-whichIt.clip.height)-17;
	        return false;}
	    return false;	}
	function dropIt() {whichIt = null;
	    if(NS) window.releaseEvents (Event.MOUSEMOVE);
	    return true;	}
	if(NS) {window.captureEvents(Event.MOUSEUP|Event.MOUSEDOWN);
		window.onmousedown = grabIt;
	 	window.onmousemove = moveIt;
		window.onmouseup = dropIt;	}
	if(IE) {
		document.onmousedown = grabIt;
	 	document.onmousemove = moveIt;
		document.onmouseup = dropIt;	}
	if(NS || IE) action = window.setInterval("heartBeat()",1);



document.write ('    <DIV align=center id=\"softkeyboard\" name=\"softkeyboard\" style=\"position:absolute; left:400px; top:333px; width:500px; z-index:180;display:none\">');
document.write ('  <table id=\"CalcTable\" width=\"\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" bgcolor=\"\">');
document.write ('      <tr> ');
document.write ('    <FORM id=Calc name=Calc action=\"\" method=post autocomplete=\"off\">');
document.write ('        <td title=\"尊敬的客户：为了保证安全,建议尽量使用软键盘输入密码!\" align=\"center\" valign=\"middle\" bgcolor=\"\" align=\"center\" style=\"cursor: default\;height:30"> <INPUT type=hidden value=\"\" name=logpass>  <INPUT type=hidden value=ok name=action2>');
document.write ('<B>为了保证您的密码的安全,请使用软键盘输入密码</B></td>');
document.write ('      </tr>');
document.write ('      <tr align=\"center\"> ');
document.write ('        <td align=\"center\" bgcolor=\"#FFFFFF\"> <table align=\"center\" width=\"%\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\">');
document.write ('            <tr align=\"left\" valign=\"middle\"> ');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'1\');\" value=\" 1 \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'2\');\" value=\" 2 \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'3\');\" value=\" 3 \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'4\');\" value=\" 4 \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'5\');\" value=\" 5 \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'6\');\" value=\" 6 \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'7\');\" value=\" 7 \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'8\');\" value=\" 8 \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'9\');\" value=\" 9 \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'0\');\" value=\" 0 \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'-\');\" value=\" - \"></td>');
document.write ('              <td><input name=\"button\" type=button onClick=\"addValue(\'=\');\" value=\"    =     \" style=\"width:100px;\"> ');
document.write ('              </td>');
//document.write ('              <td>&nbsp;</td>');
document.write ('            </tr>');
document.write ('            <tr align=\"left\" valign=\"middle\"> ');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'q\');\" value=\" q \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'w\');\" value=\" w \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'e\');\" value=\" e \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'r\');\" value=\" r \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'t\');\" value=\" t \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'y\');\" value=\" y \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'u\');\" value=\" u \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'i\');\" value=\" i \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'o\');\" value=\" o \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'p\');\" value=\" p \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" name=\"button6\" type=button onClick=\"addValue(\':\');\" value=\" : \"></td>');
document.write ('              <td><input name=\"button10\" type=button value=\" 退格\" onclick=\"setpassvalue();\"  onDblClick=\"setpassvalue();\" style=\"width:100px;\"> ');
document.write ('              </td>');
document.write ('              <td> ');
document.write ('                </td>');
document.write ('            </tr>');
document.write ('            <tr align=\"left\" valign=\"middle\"> ');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'a\');\" value=\" a \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'s\');\" value=\" s \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'d\');\" value=\" d \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'f\');\" value=\" f \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'g\');\" value=\" g \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'h\');\" value=\" h \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'j\');\" value=\" j \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'k\');\" value=\" k \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'l\');\" value=\" l \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" name=\"button8\" type=button onClick=\"addValue(\'[\');\" value=\" [ \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" name=\"button9\" type=button onClick=\"addValue(\']\');\" value=\" ] \"></td>');
document.write ('              <td><input name=\"button9\" type=button onClick=\"capsLockText();setCapsLock();\"  onDblClick=\"capsLockText();setCapsLock();\" value=\"切换大/小写\" style=\"width:100px;\"></td>');
document.write ('            </tr>');
document.write ('            <tr align=\"left\" valign=\"middle\"> ');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'z\');\" value=\" z \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'x\');\" value=\" x \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'c\');\" value=\" c \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'v\');\" value=\" v \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'b\');\" value=\" b \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'n\');\" value=\" n \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'m\');\" value=\" m \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" name=\"button3\" type=button onClick=\"addValue(\'<\');\" value=\" < \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" name=\"button4\" type=button onClick=\"addValue(\'>\');\" value=\" > \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" name=\"button5\" type=button onClick=\"addValue(\'(\');\" value=\" ( \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" name=\"button7\" type=button onClick=\"addValue(\')\');\" value=\" ) \"></td>');
document.write ('              <td> ');
document.write ('                <input name=\"button12\" type=button onclick=\"OverInput();\" value=\"   确认  \" style=\"width:100px;\"></td>');
document.write ('              </tr>');
document.write ('            <tr align=\"left\" valign=\"middle\"> ');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" name=\"button2\" type=button onClick=\"addValue(\',\');\" value=\" , \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'~\');\" value=\" ~ \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'!\');\" value=\" ! \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'@\');\" value=\" @ \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'#\');\" value=\" # \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'$\');\" value=\" $ \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'%\');\" value=\" % \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'^\');\" value=\" ^ \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'*\');\" value=\" * \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'|\');\" value=\" | \"></td>');
document.write ('              <td> ');
document.write ('                <input style=\"width:20px;\" type=button onclick=\"addValue(\'?\');\" value=\" ? \"></td>');
document.write ('              <td> ');
//document.write ('              <input name=\"button13\" type=button onclick=\"logpass1.readOnly=0;logpass1.focus()\" value=\"切换到硬键盘\" style=\"width:100px;\"></td>');
document.write ('                <input name=\"button13\" type=button onclick=\"OverInput();logpass1.readOnly=0;ifKeyBoard=1;\" value=\"切换到硬键盘\" style=\"width:100px;\"></td>');
//document.write ('              <td colspan=\"2\">&nbsp;</td>');
document.write ('            </tr>');
document.write ('          </table></td>');
document.write ('    </FORM>');
document.write ('      </tr>');
document.write ('  </table>');
document.write ('</DIV>');

//给输入的密码框添加新值
	function addValue(newValue)
	{
		if (CapsLockValue==0)
		{
			//Calc.logpass.value += newValue;
			//logpass1.value=Calc.logpass.value;
			document.Form1.User_Pass.value += newValue;   //
		}
		else
		{
			//Calc.logpass.value += newValue.toUpperCase();
			//logpass1.value=Calc.logpass.value;
			document.Form1.User_Pass.value += newValue.toUpperCase();   //
		}
	}
//实现BackSpace键的功能
	/*
	function setpassvalue()
	{
		var longnum=Calc.logpass.value.length;
		var num
		num=Calc.logpass.value.substr(0,longnum-1);
		Calc.logpass.value=num;
		logpass1.value=Calc.logpass.value;
	}
	*/
	function setpassvalue()
	{
		var longnum=document.Form1.User_Pass.value.length;
		var num
		num=document.Form1.User_Pass.value.substr(0,longnum-1);
		document.Form1.User_Pass.value=num;
		//logpass1.value=document.Form1.User_Pass.value;
	}
//输入完毕
	function OverInput()
	{
		//m_pass.mempass.value=Calc.logpass.value;
		//logpass1.value=Calc.logpass.value;  //
		//logpass1.value=logpass1.value;    //
			//alert(theForm.value);
		//theForm.value=m_pass.mempass.value;
		logpass1.readOnly=1;
		softkeyboard.style.display="none";
		//Calc.logpass.value="";    //
		//logpass1.readOnly=0;
		//logpass1.focus();
		//logpass1.value=Calc.logpass.value;
	}
//关闭软键盘
	function closekeyboard()
	{
		softkeyboard.style.display="none";
	}
//显示软键盘
	function showkeyboard()
	{
		logpass1=document.Form1.User_Pass;
		logpass1.readOnly=1;
		softkeyboard.style.display="block";
	}

//设置是否大写的值
function setCapsLock()
{
	if (CapsLockValue==0)
	{
		CapsLockValue=1
//		Calc.showCapsLockValue.value="当前是大写 ";
	}
	else 
	{
		CapsLockValue=0
//		Calc.showCapsLockValue.value="当前是小写 ";
	}
}


function setCalcborder()
{
	CalcTable.style.border="1px solid #0090FD"
}

function setHead()
{
	CalcTable.cells[0].style.backgroundColor="#7EDEFF"	
}

function setCalcButtonBg()
{
	for(var i=0;i<Calc.elements.length;i++)
	{
		if(Calc.elements[i].type=="button"&&Calc.elements[i].bgtype!="1")
		{
	//		if(i==10)
//	alert(123);
			Calc.elements[i].style.borderTopWidth= 0
			Calc.elements[i].style.borderRightWidth= 2
			Calc.elements[i].style.borderBottomWidth= 2
			Calc.elements[i].style.borderLeftWidth= 0
			Calc.elements[i].style.borderTopStyle= "none";
			Calc.elements[i].style.borderRightStyle= "solid";
			Calc.elements[i].style.borderBottomStyle= "solid";
			Calc.elements[i].style.borderLeftStyle= "none";
			//#46AC17
			Calc.elements[i].style.borderTopColor= "#118ACC";
			Calc.elements[i].style.borderRightColor= "#118ACC";
			Calc.elements[i].style.borderBottomColor= "#118ACC";
			Calc.elements[i].style.borderLeftColor= "#118ACC";
			//#CBF3B2
			Calc.elements[i].style.backgroundColor="#ADDEF8"
			
			var thisButtonValue=Calc.elements[i].value;
			thisButtonValue=thisButtonValue.trim();
			if(thisButtonValue.length==1)
			{
				Calc.elements[i].ondblclick=
					function ()
					{
						var thisButtonValue=this.value;
						thisButtonValue=thisButtonValue.trim();
						addValue(thisButtonValue);
						//alert(234)
					}
			}
			
		}
	}
}

function initCalc()
{
	setCalcborder();
	setHead();
	setCalcButtonBg();
}

String.prototype.trim = function()
{
    // 用正则表达式将前后空格
    // 用空字符串替代。
    return this.replace(/(^\s*)|(\s*$)/g, "");
}

var capsLockFlag;
capsLockFlag=true;

function capsLockText()
{
if(capsLockFlag)//改成大写
{
	for(var i=0;i<Calc.elements.length;i++)
	{
			var char=Calc.elements[i].value;
			var char=char.trim()
		if(Calc.elements[i].type=="button"&&char>="a"&&char<="z"&&char.length==1)
		{
		
			Calc.elements[i].value=" "+String.fromCharCode(char.charCodeAt(0)-32)+" "
		}
	}
}
else
{
	for(var i=0;i<Calc.elements.length;i++)
	{
			var char=Calc.elements[i].value;
			var char=char.trim()
		if(Calc.elements[i].type=="button"&&char>="A"&&char<="Z"&&char.length==1)
		{
		
			Calc.elements[i].value=" "+String.fromCharCode(char.charCodeAt(0)+32)+" "
		}
	}
}
capsLockFlag=!capsLockFlag;
}
 today=new Date();
 function initArray(){
   this.length=initArray.arguments.length
   for(var I=0;I<this.length;I++)
   this[I+1]=initArray.arguments[I]  }
   var d=new initArray(
     "������",
     "����һ",
     "���ڶ�",
     "������",
     "������",
     "������",
     "������");
document.write(
     "<font color=#CAE7F9 style='font-size:12px;font-family:Verdana'> ",
     today.getYear(),"��",
     today.getMonth()+1,"��",
     today.getDate(),"��", 
     "&nbsp;&nbsp;</font>" ); 

document.write(
     "<font color=#CAE7F9 style='font-size:12px'> ",
     d[today.getDay()+1],
     "&nbsp;&nbsp;</font>" );



  function  CurentTime(){  
        var  now  =  new  Date();  
        var  hh  =  now.getHours();  
        var  mm  =  now.getMinutes();  
        var  ss  =  now.getTime()  %  60000;  
        ss  =  (ss  -  (ss  %  1000))  /  1000;  
        var  clock  =  hh+':';  
        if  (mm  <  10)  clock  +=  '0';  
        clock  +=  mm+':';  
        if  (ss  <  10)  clock  +=  '0';  
        clock  +=  ss;  
        return(clock);  }  
// function  refreshCalendarClock(){  
//document.all.calendarClock1.innerHTML  =  Year_Month();  
//document.all.calendarClock2.innerHTML  =  Date_of_Today();  
//document.all.calendarClock3.innerHTML  =thisYear();  
//   document.all.calendarClock4.innerHTML  =  CurentTime();  }
//document.write('<font  id="calendarClock1"  >  </font>&nbsp;');
//document.write('<font  id="calendarClock2"  >  </font>,');
//document.write('<font  id="calendarClock3"  >  </font>&nbsp;');
//  document.write('<font color=#CAE7F9 style="font-size:12px;font-family:Verdana" id="calendarClock4"  >  </font>');
// setInterval('refreshCalendarClock()',1000);
